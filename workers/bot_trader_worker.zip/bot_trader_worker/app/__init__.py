"""Bot trader worker package."""
