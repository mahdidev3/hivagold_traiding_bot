"""Bot trader worker package."""
